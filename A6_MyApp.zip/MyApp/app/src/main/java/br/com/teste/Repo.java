package br.com.teste;

class Repo {
}
