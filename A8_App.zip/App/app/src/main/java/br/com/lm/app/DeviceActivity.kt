package br.com.lm.app

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_device.*

class DeviceActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_device)

        carregaDados()
    }

    fun carregaDados() {
        tvDevice.text = "Meu Device"
        tvId.text = "DEV-01"
        tvNome.text = "Device 01"
        tvDescricao.text = "Device LYM"
        tvTemperatura.text = "26"
        tvUmidade.text = "65"
        tvStatus.text = "ON"
    }
}
