package br.com.lm.myapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imgButton.setOnClickListener() {
            intent = Intent(this, DevicesActivity::class.java)
            startActivity(intent)
        }

        imgButton1.setOnClickListener() {
            intent = Intent(this, GPSActivity::class.java)
            startActivity(intent)
        }

        imgButton2.setOnClickListener() {
            intent = Intent(this, MapsActivity::class.java)
            startActivity(intent)
        }

        val contatos = mutableListOf(
            Contato("Alessandro", "(11)94217-4738"),
            Contato("Alessandro", "(11)94217-4738"),
            Contato("Alessandro", "(11)94217-4738"),
            Contato("Alessandro", "(11)94217-4738"),
            Contato("Alessandro", "(11)94217-4738"),
            Contato("Alessandro", "(11)94217-4738"),
            Contato("Alessandro", "(11)94217-4738"),
            Contato("Alessandro", "(11)94217-4738"),
            Contato("Alessandro", "(11)94217-4738"),
            Contato("Alessandro", "(11)94217-4738"),
            Contato("Alessandro", "(11)94217-4738"),
            Contato("Alessandro", "(11)94217-4738"),
            Contato("Alice", "(11)99891-5985"),
            Contato("Leonardo", "(11)99692-7283")
        )

        repeat (20) {
            contatos.add(Contato("Contato $it","(11) 99999-9999"))
        }
        val adapter = ContatosAdapter()
        rvContatos.layoutManager = LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false)
        rvContatos.adapter = adapter
        adapter.updateItems(contatos)
    }
}
