package br.com.lm.myapp

data class Contato (val nome: String, val telefone: String)