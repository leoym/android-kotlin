package br.com.lm.myapp

data class Device (val id: String, val nome: String, val descricao: String, val temperatura: String, val umidade: String, val status: String)