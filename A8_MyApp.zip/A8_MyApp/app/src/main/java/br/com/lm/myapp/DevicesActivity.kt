package br.com.lm.myapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_devices.*

class DevicesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_devices)

        val devices = mutableListOf(
            Device("DEV01","DEV-01", "DEVICE 01", "24 oC", "65 %", "on"),
            Device("DEV02","DEV-02", "DEVICE 02", "24 oC", "65 %", "on")
        )

        val adapter = DevicesAdapter()
        rvDevices.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        rvDevices.adapter = adapter
        adapter.updateItems(devices)
    }
}
