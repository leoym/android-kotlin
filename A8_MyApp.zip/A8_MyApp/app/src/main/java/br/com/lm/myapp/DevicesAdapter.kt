package br.com.lm.myapp

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

class DevicesAdapter : RecyclerView.Adapter<DevicesAdapter.ViewHolder>() {

    private lateinit var items : List<Device>

    fun updateItems(newItems: List<Device>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_devices, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val device = items[position]
        holder.tvIdDevice.text = device.id
        holder.tvNomeDevice.text = device.nome
        holder.tvDescDevice.text = device.descricao
        holder.tvTempDevice.text = device.temperatura
        holder.tvUmidDevice.text = device.umidade
        holder.tvStatusDevice.text = device.status
    }

    class ViewHolder (itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvIdDevice = itemView.findViewById<TextView>(R.id.tvIdDevice)
        val tvNomeDevice = itemView.findViewById<TextView>(R.id.tvNomeDevice)
        val tvDescDevice = itemView.findViewById<TextView>(R.id.tvDescDevice)
        val tvTempDevice = itemView.findViewById<TextView>(R.id.tvTempDevice)
        val tvUmidDevice = itemView.findViewById<TextView>(R.id.tvUmidDevice)
        val tvStatusDevice = itemView.findViewById<TextView>(R.id.tvStatusDevice)
    }
}