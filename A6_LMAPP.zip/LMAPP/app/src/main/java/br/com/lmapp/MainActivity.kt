package br.com.lmapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.StaggeredGridLayoutManager
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btQuery.setOnClickListener {
            val language = etQuery.text.toString()
            efeturarBusca(language)
        }

    }

    private fun configureList(notes: List<Repository>) {
//        val recyclerView = rvRepository
//        recyclerView.adapter = NoteListAdapter(notes, this)
//        val layoutManager = StaggeredGridLayoutManager(
//            2, StaggeredGridLayoutManager.VERTICAL)
//        recyclerView.layoutManager = layoutManager
    }

    fun efeturarBusca(language: String) {

        var retrofit = Retrofit.Builder()
            .baseUrl("https://api.github.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val service:ApiService = retrofit.create(ApiService::class.java)

         val call : Call<GitHubResult> = service.buscarRepositorios("language:$language")
        //val call : Call<GitHubResult> = service.buscarRepositorios(language)

        call.enqueue(object: Callback<GitHubResult> {
            override fun onResponse(call: Call<GitHubResult>, response: Response<GitHubResult>) {
                tvRepositorios.text = "ok"
                val result = response.body()
                if(result != null) {
                    var nomes = "OK $language: "
                    result.items.forEach{
                        //    //nomes =+ it.name + "\n"
                        nomes = "Nome: ${it.name}  Login:${it.owner.login} \n"
                    }
                    tvRepositorios.text = nomes;
                }
            }
            override fun onFailure(call: Call<GitHubResult>, t: Throwable) {
                tvRepositorios.text = "ERRO"
            }

        })

    }
}
