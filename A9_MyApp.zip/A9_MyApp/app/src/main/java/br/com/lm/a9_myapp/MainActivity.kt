package br.com.lm.a9_myapp

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock
import android.support.v7.app.WindowDecorActionBar
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.toast
import org.jetbrains.anko.uiThread
import java.lang.Exception
import java.net.URL

class MainActivity : AppCompatActivity() {

    val URL_IMAGEM2 = "https://abrilsuperinteressante.files.wordpress.com/2016/10/super_imgnao_deixe_seu_cachorro_lamber.jpg"
    val URL_IMAGEM1 = "https://statig2.akamaized.net/bancodeimagens/at/l5/b4/atl5b46xma5cipzfskosanb2v.jpgX"
    val URL_IMAGEM = "https://abrilsuperinteressante.files.wordpress.com/2018/05/filhotes-de-cachorro-alcanc3a7am-o-c3a1pice-de-fofura-com-8-semanas1.png"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (isNetworkAvailable() == true) {
            //workThread(URL_IMAGEM)
            //carregarImagemTaks().execute()
            carregarImagemAnko()
        } else {
            imgFoto.setImageResource(R.drawable.logo)
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE)
        return if (connectivityManager is ConnectivityManager) {
            val networkInfo: NetworkInfo? = connectivityManager.activeNetworkInfo
            networkInfo?.isConnected ?: false
        } else false
    }

    // Download da imagem
    fun carregarImagem (file : String): Bitmap? {
        try {
            val url = URL(file)
            val bitmap = BitmapFactory.decodeStream(url.openConnection().getInputStream())
            return bitmap
        } catch (ex: Exception) {
            Log.d("Download", "Imagem não encontrada")
            return null
        }
    }

    // 1 - Thread
    fun workThread (file: String) {
        Thread (
            Runnable {
                val bitmap = carregarImagem(file)
                imgFoto.post {
                    imgFoto.setImageBitmap(bitmap)
                    if (bitmap == null)
                        toast ("Erro").show()
                }
            }
        ).start()
    }

    // 2 - Async
    inner class carregarImagemTaks : AsyncTask<Void, Void, Bitmap?>() {
        override fun doInBackground(vararg params: Void?): Bitmap? {
            SystemClock.sleep(2000)
            return carregarImagem(URL_IMAGEM1)
        }

        override fun onPreExecute() {
            pbFoto.visibility = View.VISIBLE
            imgFoto.visibility = View.GONE
            super.onPreExecute()
        }

        override fun onPostExecute(result: Bitmap?) {
            super.onPostExecute(result)
            imgFoto.setImageBitmap(result)
            if (result == null)
                toast("Erro").show()
            pbFoto.visibility = View.GONE
            imgFoto.visibility = View.VISIBLE
        }
    }

    // 3 - Anko
    fun carregarImagemAnko() {
        pbFoto.visibility = View.VISIBLE
        imgFoto.visibility = View.GONE

        doAsync {
            val bitmap = carregarImagem(URL_IMAGEM2)
            uiThread {
                imgFoto.setImageBitmap(bitmap)
                pbFoto.visibility = View.GONE
                imgFoto.visibility = View.VISIBLE
                if (bitmap == null)
                    toast("Erro").show()
            }
        }
    }

    // Menu
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_threads, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {

        when(item!!.itemId) {
            R.id.mnuBasic -> { workThread(URL_IMAGEM)}
            R.id.mnuAsync -> carregarImagemTaks().execute()
            R.id.mnuAnko -> carregarImagemAnko()
            R.id.mnuDelete -> imgFoto.setImageResource(R.drawable.logo)
            R.id.app_bar_search -> imgFoto.setImageResource(R.drawable.abc_btn_check_material)
        }
        return super.onOptionsItemSelected(item)
    }
}
