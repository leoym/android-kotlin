package br.com.lm.a10_myapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.support.v4.app.NotificationCompat
import android.support.v4.app.NotificationManagerCompat
import android.support.v4.content.FileProvider
import com.bumptech.glide.Glide
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_main.*
import org.jetbrains.anko.alert
import org.jetbrains.anko.okButton
import org.jetbrains.anko.toast
import java.io.File
import java.io.IOException
import java.lang.Exception
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {


    val IMAGE_URL = "https://www.catster.com/wp-content/uploads/2017/08/A-fluffy-cat-looking-funny-surprised-or-concerned.jpg"
    val IMAGE_URL1 = "https://atlantahumane.org/wp-content/uploads/2012/08/adopt-a-cat-1200x630.png"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnAlerta.setOnClickListener {
            alert("Olá Mundo", "Hello World") {
                okButton {}
            }.show()
        }

        btnNotificacao.setOnClickListener {
            enviarNotificacao("Samsung Ocean","Ocean")
        }

        btnDownload.setOnClickListener {
            downLoadImage(IMAGE_URL)
        }

        btnDownloadGlide.setOnClickListener {
            downLoadImageGlide("http://www.lymlab.com.br/wp-content/uploads/2018/05/logotipo.png")
            downLoadImageGlide(IMAGE_URL1)
        }

        btnFoto.setOnClickListener {
            takePicture()
        }
    }

    // NOTIFICAÇÕES
    fun enviarNotificacao(texto: String, titulo: String) {
        val CHANNEL_ID = "Samsung Ocean"
        val NOTIFICACAO_ID = 1

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val canalNotificacao = NotificationChannel(CHANNEL_ID, "Alertas Samsung", NotificationManager.IMPORTANCE_DEFAULT)
                .apply { description = "Alertas do App Samsung" }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(canalNotificacao)
        }
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setLargeIcon(BitmapFactory.decodeResource(resources, R.mipmap.ic_launcher))
            .setContentText(texto)
            .setContentTitle(titulo)
            .setDefaults(Notification.DEFAULT_VIBRATE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)

        val notificacao = builder.build()
        val notificationManager = NotificationManagerCompat.from(this)
        notificationManager.notify(NOTIFICACAO_ID, notificacao)
    }

    // DOWNLOAD DE IMAGENS
    fun downLoadImage(url : String) {
        Picasso.get().load(url).into(imageView)
    }

    fun downLoadImageGlide(url : String) {
        Glide.with(this).load(url).into(imageView);
    }

    // FOTOS
    val REQUEST_IMAGE_CAPTURE = 1

    fun takePicture() {
        dispatchTakePictureIntent()
    }

    private fun dispatchTakePictureIntent() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            takePictureIntent.resolveActivity(packageManager)?.also {
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
            }
        }
    }

    val REQUEST_TAKE_PHOTO = 1

    private fun dispatchTakePictureIntent1() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            // Ensure that there's a camera activity to handle the intent
            takePictureIntent.resolveActivity(packageManager)?.also {
                // Create the File where the photo should go
                val photoFile: File? = try {
                    createImageFile()
                } catch (ex: IOException) {
                    // Error occurred while creating the File
                    null
                }
                // Continue only if the File was successfully created
                photoFile?.also {
                    val photoURI: Uri = FileProvider.getUriForFile(
                        this,
                        "br.com.lm.a10_myapp.fileprovider",
                        it
                    )
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO)
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent) {
        toast("Foto - $requestCode - $resultCode.")
        try {
            if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
                val imageBitmap = data.extras.get("data") as Bitmap
                if (imageBitmap != null) {
                    imageView.setImageBitmap(imageBitmap)
                }
            }
        } catch (ex: Exception) {
            toast("Erro ao tirar foto.")
        }
    }

    var currentPhotoPath: String = ""

    @Throws(IOException::class)
    private fun createImageFile(): File {
        // Create an image file name
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            "JPEG_${timeStamp}_", /* prefix */
            ".jpg", /* suffix */
            storageDir /* directory */
        ).apply {
            // Save a file: path for use with ACTION_VIEW intents
            currentPhotoPath = absolutePath
        }
    }

    fun wipSendData() {

    }

}

