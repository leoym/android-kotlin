package br.com.a7_lm_100619

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    lateinit var dbm : DatabaseManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbm = DatabaseManager (DatabaseHelper(this))

        listarContatos()

        btSalvar.setOnClickListener {
            val nome = etNome.text.toString()
            val telefone = etFone.text.toString()
            salvarContato(nome, telefone)
        }

        btContatos.setOnClickListener {
            listarContatos()
        }

        btContato.setOnClickListener {
            listarContato()
        }
    }

    fun salvarContato(nome: String, telefone: String) {
        val inserir = dbm.inserirContato(nome, telefone)
        tvResult.text = "Gravar contato: $nome - $telefone : $inserir"
    }

    fun listarContatos() {
        val contatos : List<Contato> = dbm.selecionarContatos()
        var cont = 0
        lyContatos.removeAllViews()
        contatos.forEach {
            //cont = cont + 1
            //Toast.makeText(this, "$cont: ${it.nome} ${it.telefone}", Toast.LENGTH_LONG).show()
            val tvContato = TextView(this)
            tvContato.text = it.nome
            tvContato.setOnClickListener {v->
                Toast.makeText(this, "${it.nome} ${it.telefone}", Toast.LENGTH_LONG).show()
            }
            lyContatos.addView(tvContato)
        }
    }

    fun listarContato() {
        val contatos : List<Contato> = dbm.selecionarContato("1")

        dbm.excluirContato(3)
        dbm.excluirContato(4)
        dbm.excluirContato(5)
        dbm.excluirContato(6)
        dbm.excluirContato(7)
        dbm.excluirContato(9)
        dbm.excluirContato(8)
        dbm.excluirContato(10)

        var cont = 0
        lyContatos.removeAllViews()
        contatos.forEach {
            //cont = cont + 1
            //Toast.makeText(this, "$cont: ${it.nome} ${it.telefone}", Toast.LENGTH_LONG).show()
            val tvContato = TextView(this)
            tvContato.text = it.nome
            lyContatos.addView(tvContato)
        }
    }
}
