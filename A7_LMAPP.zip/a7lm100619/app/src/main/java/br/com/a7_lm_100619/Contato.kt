package br.com.a7_lm_100619

data class Contato ( var nome : String, var telefone: String )