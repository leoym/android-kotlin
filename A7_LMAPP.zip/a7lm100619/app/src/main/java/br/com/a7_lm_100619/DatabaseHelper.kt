package br.com.a7_lm_100619

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper (context: Context?):
    SQLiteOpenHelper(context, "ocean_db", null, 1) {
    override fun onCreate(db: SQLiteDatabase?) {
        var sql = """
            CREATE TABLE contatos ( id integer PRIMARY KEY,
            nome TEXT,
            telefone TEXT
            );
        """.trimIndent()

        db?.execSQL(sql)

    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {

    }
}