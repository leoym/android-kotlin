package br.com.a7_lm_100619

import android.content.ContentValues

class DatabaseManager (val dbHelper: DatabaseHelper) {

    fun inserirContato(nome: String, telefone: String): Long {

        /*
        var sql = """
            INSERT INTO contatos VALUES(nome,
            telefone) ($nome , $telefone);
        """.trimIndent()
        db?.execSQL(sql)
        val valores = ContentValues()
        valores.put("nome", $nome)
        valores.put("telefone", $telefone)
        db.insert("contatos", valores)
        */
        val db = dbHelper.writableDatabase
        val valores = ContentValues().apply {
            put("nome", nome)
            put("telefone", telefone)
        }
        val id = db.insert("contatos", null, valores)
        return id
    }

    fun selecionarContatos() : List<Contato> {
        val db = dbHelper.writableDatabase
        var sql = "SELECT * FROM contatos"

        val cursor = db.rawQuery(sql, null)

        val resultado = mutableListOf<Contato>()

        if (cursor.moveToFirst()) {
            do {
                val nomeDb: String = cursor.getString(cursor.getColumnIndex("nome"))
                val foneDb: String = cursor.getString(cursor.getColumnIndex("telefone"))
                resultado.add(Contato(nomeDb,foneDb))
            } while(cursor.moveToNext())
            cursor.close()
        }
        return resultado
    }

    fun selecionarContato(id : String) : List<Contato> {
        val db = dbHelper.writableDatabase
        var sql = "SELECT * FROM contatos WHERE id = '1'"

        val cursor = db.rawQuery(sql, null)

        val resultado = mutableListOf<Contato>()

        if (cursor.moveToFirst()) {
            do {
                val nomeDb: String = cursor.getString(cursor.getColumnIndex("nome"))
                val foneDb: String = cursor.getString(cursor.getColumnIndex("telefone"))
                resultado.add(Contato(nomeDb, foneDb))
            } while(cursor.moveToNext())
            cursor.close()
        }
        return resultado
    }

    fun excluirContato(id: Long) {
        val db = dbHelper.writableDatabase
        db.delete("contatos", "id = $id", null)
    }
}