package br.com.lmapp

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import br.com.lmapp.model.GitHubResult
import br.com.lmapp.model.Repository
import br.com.lmapp.presenter.MainPresenter
import br.com.lmapp.services.ApiService
import br.com.lmapp.view.MainView
import br.com.lmapp.viewmodel.MainViewModel
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity(), MainView {

    lateinit var presenter : MainPresenter

    val viewmodel by lazy {
        ViewModelProviders.of(this).get(MainViewModel::class.java)

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btQuery.setOnClickListener {
            val language = etQuery.text.toString()
            viewmodel.fetchRepositories(language)
        }
        progressBar.visibility = View.GONE
        viewmodel.repositories.observe(this, Observer {
            it?.let{
                var nomes = ""
                it.forEach{
                    nomes = nomes + "Nome: ${it.name}  Login:${it.owner.login} \n"
                }
                tvRepositorios.text = nomes;
            }
        } )

        viewmodel.loading.observe(this, Observer {
            if (it == true) {
                progressBar.visibility = View.GONE
            } else {
                progressBar.visibility = View.VISIBLE
            }
        })

        viewmodel.erro.observe(this, Observer {
            tvErro.text = viewmodel.erro.value
        })
        /*
        presenter = MainPresenter(this)

        btQuery.setOnClickListener {
            onButtonClick()
        }
        */
    }

    override fun onButtonClick() {
        val language = etQuery.text.toString()
        presenter.fetchRepositories(language)
    }

    override fun showList(repositories: List<Repository>) {
        if (repositories != null) {
            var nomes = ""
            repositories.forEach{
                //    //nomes =+ it.name + "\n"
                nomes = nomes + "Nome: ${it.name}  Login:${it.owner.login} \n"
            }
            tvRepositorios.text = nomes
        } else {
            tvRepositorios.text = "Erro"
        }
    }
}
