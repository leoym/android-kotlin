package br.com.lmapp.presenter

import br.com.lmapp.model.GitHubResult
import br.com.lmapp.model.Repository
import br.com.lmapp.services.ApiService
import br.com.lmapp.view.MainView
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainPresenter (val view: MainView){

    fun fetchRepositories(language: String) {
        var retrofit = Retrofit.Builder()
            .baseUrl("https://api.github.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val service: ApiService = retrofit.create(ApiService::class.java)

        val call : Call<GitHubResult> = service.buscarRepositorios("language:$language")
        //val call : Call<GitHubResult> = service.buscarRepositorios(language)

        call.enqueue(object: Callback<GitHubResult> {
            override fun onResponse(call: Call<GitHubResult>, response: Response<GitHubResult>) {
                //tvRepositorios.text = "ok"
                val result = response.body()
                if(result != null) {
                    view.showList(result.items)
                }
            }
            override fun onFailure(call: Call<GitHubResult>, t: Throwable) {
                //tvRepositorios.text = "ERRO"
            }
        })
    }
}