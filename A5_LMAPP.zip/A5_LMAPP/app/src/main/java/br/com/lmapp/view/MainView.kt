package br.com.lmapp.view

import br.com.lmapp.model.Repository

interface MainView {

    fun onButtonClick()

    fun showList(repositories: List<Repository>)
}